# Aihubmix Image Generation Plugin 部署指南

## 本地测试

### 环境要求

- Python 3.12+
- Dify Plugin SDK >= 0.4.0
- 有效的 Aihubmix API Key

### 本地测试步骤

1. **安装依赖**
   ```bash
   pip install -r requirements.txt
   ```

2. **配置环境变量**
   ```bash
   # 复制环境变量模板
   cp .env.example .env
   
   # 编辑 .env 文件，添加您的 API Key
   echo "AIHUBMIX_API_KEY=your_api_key_here" >> .env
   ```

3. **运行本地测试**
   ```bash
   # 运行主程序进行基本测试
   python main.py
   ```

4. **测试 API 连接**
   ```python
   # 创建测试脚本 test_api.py
   import requests
   
   def test_api_connection():
       api_key = "your_api_key_here"
       headers = {
           "Authorization": f"Bearer {api_key}",
           "Content-Type": "application/json"
       }
       
       try:
           response = requests.get(
               "https://api.aihubmix.com/v1/models",
               headers=headers,
               timeout=10
           )
           
           if response.status_code == 200:
               print("✅ API 连接成功")
               print(f"可用模型: {len(response.json().get('data', []))}")
           else:
               print(f"❌ API 连接失败: {response.status_code}")
               
       except Exception as e:
           print(f"❌ 连接错误: {str(e)}")
   
   if __name__ == "__main__":
       test_api_connection()
   ```

### 功能测试

测试不同的模型和参数组合：

```python
# test_image_generation.py
import json
import sys
import os

# 添加插件路径
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from tools.aihubmix_image import AihubmixImageTool
from dify_plugin.entities.tool import ToolInvokeMessage

def test_sync_generation():
    """测试同步模型"""
    tool = AihubmixImageTool()
    
    # 模拟运行时环境
    class MockRuntime:
        credentials = {"api_key": "your_api_key_here"}
    
    tool.runtime = MockRuntime()
    
    # 测试参数
    test_params = {
        "prompt": "A beautiful sunset over mountains",
        "model": "opanai/dall-e-3",
        "resolution": "1024x1024",
        "num_images": 1,
        "moderation_level": 3
    }
    
    try:
        results = list(tool._invoke(test_params))
        for result in results:
            print(f"结果类型: {result.type}")
            print(f"结果内容: {result.message}")
    except Exception as e:
        print(f"测试失败: {str(e)}")

def test_async_generation():
    """测试异步模型"""
    tool = AihubmixImageTool()
    
    class MockRuntime:
        credentials = {"api_key": "your_api_key_here"}
    
    tool.runtime = MockRuntime()
    
    # 测试异步模型
    test_params = {
        "prompt": "A futuristic city with flying cars",
        "model": "bfl/flux-kontext-pro",
        "resolution": "1024x1024",
        "num_images": 1,
        "moderation_level": 3
    }
    
    try:
        results = list(tool._invoke(test_params))
        for result in results:
            print(f"结果类型: {result.type}")
            print(f"结果内容: {result.message}")
    except Exception as e:
        print(f"测试失败: {str(e)}")

if __name__ == "__main__":
    print("🧪 开始测试 Aihubmix Image Generation Plugin")
    
    print("\n📸 测试同步模型...")
    test_sync_generation()
    
    print("\n⏳ 测试异步模型...")
    test_async_generation()
    
    print("\n✅ 测试完成")
```

## 打包发布

### 1. 创建插件包

```bash
# 确保在项目根目录
cd /path/to/aihubmix-image

# 创建插件包
zip -r aihubmix-image.zip . -x "*.git*" "*.DS_Store*" "__pycache__/*" "*.pyc" ".env*" "test_*"

# 验证包内容
unzip -l aihubmix-image.zip
```

### 2. 插件包结构检查

确保插件包包含以下文件：

```
aihubmix-image.zip
├── manifest.yaml              # 插件清单文件
├── requirements.txt           # Python 依赖
├── provider/
│   ├── aihubmix-image.yaml   # Provider 配置
│   └── aihubmix-image.py     # Provider 实现
├── tools/
│   ├── aihubmix-image.yaml   # Tool 配置
│   └── aihubmix-image.py     # Tool 实现
├── _assets/
│   ├── icon.svg              # 插件图标
│   └── icon-dark.svg         # 深色模式图标
├── USAGE.md                  # 使用说明
├── DEPLOYMENT.md             # 部署指南
├── PRIVACY.md               # 隐私政策
├── README.md                # 项目说明
└── .difyignore              # 忽略文件配置
```

### 3. 上传到 Dify

#### 通过 Web 界面上传

1. 登录 Dify 管理后台
2. 进入「插件管理」→「插件市场」
3. 点击「上传插件」
4. 选择 `aihubmix-image.zip` 文件
5. 填写插件信息：
   - **插件名称**: aihubmix-image
   - **版本**: 0.0.1
   - **描述**: 基于 Aihubmix API 的图像生成工具
   - **作者**: xinrui
6. 点击「上传并发布」

#### 通过 API 上传

```bash
# 使用 curl 上传插件
curl -X POST \
  "https://your-dify-domain.com/api/v1/plugins/upload" \
  -H "Authorization: Bearer YOUR_ADMIN_TOKEN" \
  -F "file=@aihubmix-image.zip" \
  -F "name=aihubmix-image" \
  -F "version=0.0.1" \
  -F "description=基于 Aihubmix API 的图像生成工具"
```

### 4. 验证安装

1. 在插件列表中确认插件已安装
2. 检查插件状态是否为「已启用」
3. 测试插件配置功能
4. 创建测试应用验证功能

## 版本管理

### 版本号规范

遵循语义化版本控制 (SemVer)：
- **主版本号**: 不兼容的 API 修改
- **次版本号**: 向下兼容的功能性新增
- **修订号**: 向下兼容的问题修正

### 发布流程

1. **更新版本号**
   ```yaml
   # manifest.yaml
   version: 0.0.2
   ```

2. **更新 CHANGELOG**
   ```markdown
   ## [0.0.2] - 2024-XX-XX
   
   ### 新增
   - 新增 XXX 功能
   
   ### 修复
   - 修复 XXX 问题
   
   ### 改进
   - 优化 XXX 性能
   ```

3. **重新打包**
   ```bash
   zip -r aihubmix-image-v0.0.2.zip . -x "*.git*" "*.DS_Store*" "__pycache__/*" "*.pyc" ".env*" "test_*"
   ```

4. **上传新版本**
   - 在 Dify 中上传新版本
   - 更新插件信息
   - 发布更新

## 监控和维护

### 日志监控

在 Dify 中监控插件运行状态：

1. **应用日志**
   - 查看插件调用日志
   - 监控错误率和响应时间
   - 分析用户使用模式

2. **系统日志**
   - 监控插件资源使用
   - 检查内存和 CPU 占用
   - 确保插件稳定性

### 性能优化

1. **响应时间优化**
   - 异步模型轮询间隔调整
   - 网络超时时间优化
   - 缓存机制实现

2. **资源使用优化**
   - 内存使用监控
   - 并发请求限制
   - 垃圾回收优化

### 故障处理

1. **常见问题**
   - API Key 失效处理
   - 网络连接超时
   - 模型服务不可用

2. **应急响应**
   - 快速回滚机制
   - 备用 API 切换
   - 用户通知机制

## 安全考虑

### API Key 安全

1. **存储安全**
   - 使用 Dify 的密文存储
   - 定期轮换 API Key
   - 访问权限控制

2. **传输安全**
   - HTTPS 加密传输
   - 请求签名验证
   - 防重放攻击

### 内容安全

1. **内容审核**
   - 多级审核机制
   - 敏感内容过滤
   - 用户举报处理

2. **使用限制**
   - 频率限制
   - 配额管理
   - 异常检测

## 技术支持

### 联系方式

- **技术文档**: [USAGE.md](USAGE.md)
- **问题反馈**: GitHub Issues
- **技术支持**: support@aihubmix.com

### 社区支持

- **用户社区**: Dify 官方论坛
- **开发者群**: 微信/QQ 群
- **技术博客**: 定期发布使用技巧

---

**注意**: 请确保在生产环境中使用前进行充分的测试，并定期更新插件以获得最新功能和安全修复。
