# Aihubmix Image Generation Plugin 使用说明

## 概述

这是一个基于 Aihubmix API 的 Dify 图像生成插件，支持同步和异步模型调用，可被 Dify 的 ChatFlow、Agent、Workflow 应用直接调用。

## 功能特性

- ✅ 支持多种图像生成模型（同步/异步）
- ✅ 可配置图像分辨率和生成数量
- ✅ 内容审核宽松度调节
- ✅ 异步模型自动轮询获取结果
- ✅ 完整的错误处理和重试机制
- ✅ API Key 安全存储

## 支持的模型

### 同步模型（即时返回结果）
- `opanai/dall-e-3` - DALL-E 3
- `opanai/gpt-image-1` - GPT Image 1
- `stability/Stable-Diffusion-3-5-Large` - Stable Diffusion 3.5 Large
- `qianfan/qwen-image` - Qwen Image

### 异步模型（需要轮询）
- `bfl/flux-kontext-max` - Flux Kontext Max
- `bfl/flux-kontext-pro` - Flux Kontext Pro

## 安装步骤

### 1. 获取 Aihubmix API Key

1. 访问 [Aihubmix 官网](https://docs.aihubmix.com)
2. 注册账号并登录
3. 在控制台中生成 API Key
4. 复制 API Key 备用

### 2. 在 Dify 中安装插件

1. 登录 Dify 管理后台
2. 进入「插件管理」页面
3. 点击「安装插件」
4. 选择「上传插件文件」
5. 上传 `aihubmix-image.zip` 插件包
6. 等待安装完成

### 3. 配置 API Key

1. 在插件列表中找到「aihubmix-image」
2. 点击「配置」
3. 输入您的 Aihubmix API Key
4. 点击「保存」
5. 系统会自动验证 API Key 的有效性

## 使用方法

### 在 ChatFlow 中使用

1. 创建新的 ChatFlow 应用
2. 在工具节点中选择「aihubmix-image」
3. 配置参数：
   - **提示词**（必填）：描述您想要生成的图像
   - **模型**：选择合适的图像生成模型
   - **分辨率**：选择输出图像的分辨率
   - **生成数量**：设置生成图像的数量（1-4）
   - **审核宽松度**：设置内容审核的严格程度（0-6）

### 在 Agent 中使用

1. 创建新的 Agent 应用
2. 在工具配置中启用「aihubmix-image」
3. Agent 可以根据对话内容自动调用图像生成功能

### 在 Workflow 中使用

1. 创建新的 Workflow 应用
2. 添加工具节点
3. 选择「aihubmix-image」工具
4. 配置输入参数（可以使用变量引用）

## 参数说明

| 参数 | 类型 | 必填 | 默认值 | 说明 |
|------|------|------|--------|------|
| prompt | string | 是 | - | 图像生成提示词 |
| model | select | 否 | opanai/dall-e-3 | 图像生成模型 |
| resolution | select | 否 | 1024x1024 | 图像分辨率 |
| num_images | number | 否 | 1 | 生成图像数量（1-4） |
| moderation_level | number | 否 | 3 | 审核宽松度（0-6） |

## 返回格式

插件会返回以下格式的数据：

```json
{
  "success": true,
  "model": "opanai/dall-e-3",
  "prompt": "A beautiful sunset over mountains",
  "resolution": "1024x1024",
  "num_images": 1,
  "images": [
    {
      "url": "https://example.com/generated-image.png"
    }
  ],
  "moderation_level": 3
}
```

## 错误处理

插件包含完整的错误处理机制：

- **API Key 错误**：提示用户检查 API Key 是否正确
- **参数错误**：提示用户检查输入参数的有效性
- **网络错误**：自动重试机制，最多重试 10 次
- **异步超时**：异步模型最长等待 20 秒（10 次 × 2 秒）
- **内容审核**：根据设置的宽松度进行内容过滤

## 最佳实践

### 1. 模型选择建议

- **高质量图像**：推荐使用 `opanai/dall-e-3` 或 `bfl/flux-kontext-pro`
- **快速生成**：推荐使用 `opanai/gpt-image-1`
- **艺术风格**：推荐使用 `stability/Stable-Diffusion-3-5-Large`
- **中文优化**：推荐使用 `qianfan/qwen-image`

### 2. 提示词优化

- 使用具体、详细的描述
- 包含风格、色彩、构图等要素
- 避免模糊或抽象的描述
- 可以参考优秀作品的描述方式

### 3. 分辨率选择

- **1024x1024**：标准正方形，适合大多数场景
- **768x1024**：竖版，适合人物、肖像
- **1024x2048**：宽版，适合风景、全景

### 4. 审核设置

- **0-2**：严格模式，适合正式场合
- **3-4**：平衡模式，适合一般用途
- **5-6**：宽松模式，适合创意场景

## 故障排除

### 常见问题

1. **API Key 验证失败**
   - 检查 API Key 是否正确复制
   - 确认 API Key 是否有效
   - 检查网络连接是否正常

2. **图像生成失败**
   - 检查提示词是否符合内容政策
   - 尝试降低审核宽松度
   - 更换其他模型重试

3. **异步模型超时**
   - 这是正常现象，复杂图像需要更长时间
   - 可以尝试简化提示词
   - 选择同步模型获得更快响应

4. **生成数量限制**
   - 单次最多生成 4 张图像
   - 如需更多图像，请多次调用

### 日志查看

在 Dify 的应用日志中可以查看详细的调用信息：
- API 请求参数
- 响应状态和时间
- 错误信息和堆栈跟踪

## 技术支持

如遇到问题，请：

1. 查看本文档的故障排除部分
2. 检查 Dify 应用日志
3. 联系 Aihubmix 技术支持
4. 提交 Issue 到插件仓库

## 更新日志

### v0.0.1
- 初始版本发布
- 支持同步和异步图像生成
- 完整的参数配置和错误处理
- 多语言界面支持

---

**注意**：使用本插件需要消耗 Aihubmix API 配额，请合理使用以避免超出限制。
