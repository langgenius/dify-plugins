#!/usr/bin/env python3
"""
Aihubmix Image Generation Plugin 测试脚本

用于验证插件的基本功能，包括：
- 参数验证
- API 调用
- 错误处理
- 返回格式
"""

import os
import sys
import json
from typing import Dict, Any

# 添加插件路径到 Python 路径
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from tools.aihubmix_image import AihubmixImageTool


class MockRuntime:
    """模拟运行时环境"""
    def __init__(self, credentials: Dict[str, str]):
        self.credentials = credentials


def test_sync_model():
    """测试同步模型"""
    print("🧪 测试同步模型...")
    
    # 创建工具实例
    tool = AihubmixImageTool()
    tool.runtime = MockRuntime({"api_key": os.getenv("AIHUBMIX_API_KEY", "test_key")})
    
    # 测试参数
    params = {
        "prompt": "a beautiful sunset over mountains",
        "model": "opanai/dall-e-3",
        "size": "1024x1024",
        "n": 1,
        "moderation_level": 3
    }
    
    try:
        messages = list(tool._invoke(params))
        for message in messages:
            print(f"📝 消息类型: {type(message).__name__}")
            if hasattr(message, 'message'):
                print(f"📄 内容: {message.message}")
            elif hasattr(message, 'data'):
                print(f"📊 数据: {json.dumps(message.data, indent=2, ensure_ascii=False)}")
        print("✅ 同步模型测试完成")
    except Exception as e:
        print(f"❌ 同步模型测试失败: {str(e)}")


def test_async_model():
    """测试异步模型"""
    print("\n🧪 测试异步模型...")
    
    tool = AihubmixImageTool()
    tool.runtime = MockRuntime({"api_key": os.getenv("AIHUBMIX_API_KEY", "test_key")})
    
    params = {
        "prompt": "a futuristic city with flying cars",
        "model": "bfl/flux-kontext-max",
        "size": "1024x1024",
        "n": 1,
        "moderation_level": 3
    }
    
    try:
        messages = list(tool._invoke(params))
        for message in messages:
            print(f"📝 消息类型: {type(message).__name__}")
            if hasattr(message, 'message'):
                print(f"📄 内容: {message.message}")
            elif hasattr(message, 'data'):
                print(f"📊 数据: {json.dumps(message.data, indent=2, ensure_ascii=False)}")
        print("✅ 异步模型测试完成")
    except Exception as e:
        print(f"❌ 异步模型测试失败: {str(e)}")


def test_parameter_validation():
    """测试参数验证"""
    print("\n🧪 测试参数验证...")
    
    tool = AihubmixImageTool()
    tool.runtime = MockRuntime({"api_key": os.getenv("AIHUBMIX_API_KEY", "test_key")})
    
    # 测试空提示词
    print("🔍 测试空提示词...")
    params = {"prompt": ""}
    try:
        messages = list(tool._invoke(params))
        for message in messages:
            if hasattr(message, 'message'):
                print(f"📄 错误信息: {message.message}")
        print("✅ 空提示词验证通过")
    except Exception as e:
        print(f"❌ 空提示词验证失败: {str(e)}")
    
    # 测试无效图像数量
    print("\n🔍 测试无效图像数量...")
    params = {
        "prompt": "test",
        "n": 5  # 超出范围
    }
    try:
        messages = list(tool._invoke(params))
        for message in messages:
            if hasattr(message, 'message'):
                print(f"📄 错误信息: {message.message}")
        print("✅ 无效图像数量验证通过")
    except Exception as e:
        print(f"❌ 无效图像数量验证失败: {str(e)}")
    
    # 测试无效审核级别
    print("\n🔍 测试无效审核级别...")
    params = {
        "prompt": "test",
        "moderation_level": 7  # 超出范围
    }
    try:
        messages = list(tool._invoke(params))
        for message in messages:
            if hasattr(message, 'message'):
                print(f"📄 错误信息: {message.message}")
        print("✅ 无效审核级别验证通过")
    except Exception as e:
        print(f"❌ 无效审核级别验证失败: {str(e)}")


def test_missing_api_key():
    """测试缺失 API Key"""
    print("\n🧪 测试缺失 API Key...")
    
    tool = AihubmixImageTool()
    tool.runtime = MockRuntime({})  # 没有 API Key
    
    params = {
        "prompt": "test image",
        "model": "opanai/dall-e-3"
    }
    
    try:
        messages = list(tool._invoke(params))
        for message in messages:
            if hasattr(message, 'message'):
                print(f"📄 错误信息: {message.message}")
        print("✅ 缺失 API Key 验证通过")
    except Exception as e:
        print(f"❌ 缺失 API Key 验证失败: {str(e)}")


def test_unsupported_model():
    """测试不支持的模型"""
    print("\n🧪 测试不支持的模型...")
    
    tool = AihubmixImageTool()
    tool.runtime = MockRuntime({"api_key": os.getenv("AIHUBMIX_API_KEY", "test_key")})
    
    params = {
        "prompt": "test image",
        "model": "unsupported/model"
    }
    
    try:
        messages = list(tool._invoke(params))
        for message in messages:
            if hasattr(message, 'message'):
                print(f"📄 错误信息: {message.message}")
        print("✅ 不支持模型验证通过")
    except Exception as e:
        print(f"❌ 不支持模型验证失败: {str(e)}")


def main():
    """主测试函数"""
    print("🚀 开始 Aihubmix Image Generation Plugin 测试")
    print("=" * 50)
    
    # 检查环境变量
    api_key = os.getenv("AIHUBMIX_API_KEY")
    if not api_key:
        print("⚠️  警告: 未设置 AIHUBMIX_API_KEY 环境变量")
        print("   某些测试可能会失败")
        print("   设置方法: export AIHUBMIX_API_KEY='your_api_key_here'")
        print()
    
    # 运行测试
    try:
        test_parameter_validation()
        test_missing_api_key()
        test_unsupported_model()
        
        if api_key:
            test_sync_model()
            test_async_model()
        else:
            print("\n⏭️  跳过 API 调用测试（需要有效的 API Key）")
        
        print("\n" + "=" * 50)
        print("🎉 所有测试完成！")
        
    except KeyboardInterrupt:
        print("\n⏹️  测试被用户中断")
    except Exception as e:
        print(f"\n💥 测试过程中发生错误: {str(e)}")
        sys.exit(1)


if __name__ == "__main__":
    main()
