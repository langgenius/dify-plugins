#!/usr/bin/env python3
"""
Aihubmix Image Generation Plugin 构建脚本

用于验证插件完整性并创建发布包
"""

import os
import sys
import zipfile
import hashlib
from pathlib import Path


def calculate_file_hash(filepath: str) -> str:
    """计算文件的 MD5 哈希值"""
    hash_md5 = hashlib.md5()
    with open(filepath, "rb") as f:
        for chunk in iter(lambda: f.read(4096), b""):
            hash_md5.update(chunk)
    return hash_md5.hexdigest()


def validate_plugin_structure():
    """验证插件目录结构"""
    print("🔍 验证插件目录结构...")
    
    required_files = [
        "manifest.yaml",
        "provider/aihubmix-image.yaml",
        "provider/aihubmix-image.py",
        "tools/aihubmix-image.yaml",
        "tools/aihubmix-image.py",
        "requirements.txt",
        "_assets/icon.svg",
        "_assets/icon-dark.svg",
        "main.py"
    ]
    
    missing_files = []
    for file_path in required_files:
        if not os.path.exists(file_path):
            missing_files.append(file_path)
    
    if missing_files:
        print("❌ 缺少必要文件:")
        for file_path in missing_files:
            print(f"   - {file_path}")
        return False
    
    print("✅ 目录结构验证通过")
    return True


def validate_yaml_syntax():
    """验证 YAML 文件语法"""
    print("\n🔍 验证 YAML 文件语法...")
    
    try:
        import yaml
    except ImportError:
        print("⚠️  警告: 未安装 PyYAML，跳过 YAML 语法验证")
        return True
    
    yaml_files = [
        "manifest.yaml",
        "provider/aihubmix-image.yaml",
        "tools/aihubmix-image.yaml"
    ]
    
    for yaml_file in yaml_files:
        try:
            with open(yaml_file, 'r', encoding='utf-8') as f:
                yaml.safe_load(f)
            print(f"✅ {yaml_file} 语法正确")
        except yaml.YAMLError as e:
            print(f"❌ {yaml_file} 语法错误: {e}")
            return False
        except Exception as e:
            print(f"❌ {yaml_file} 验证失败: {e}")
            return False
    
    return True


def validate_python_syntax():
    """验证 Python 文件语法"""
    print("\n🔍 验证 Python 文件语法...")
    
    python_files = [
        "provider/aihubmix-image.py",
        "tools/aihubmix-image.py",
        "main.py",
        "test_plugin.py",
        "build_plugin.py"
    ]
    
    for python_file in python_files:
        try:
            with open(python_file, 'r', encoding='utf-8') as f:
                compile(f.read(), python_file, 'exec')
            print(f"✅ {python_file} 语法正确")
        except SyntaxError as e:
            print(f"❌ {python_file} 语法错误: {e}")
            return False
        except Exception as e:
            print(f"❌ {python_file} 验证失败: {e}")
            return False
    
    return True


def check_dependencies():
    """检查依赖文件"""
    print("\n🔍 检查依赖文件...")
    
    try:
        with open("requirements.txt", 'r') as f:
            requirements = f.read().strip()
        
        if not requirements:
            print("❌ requirements.txt 为空")
            return False
        
        print("✅ requirements.txt 内容正确")
        print(f"📦 依赖列表:\n{requirements}")
        return True
        
    except Exception as e:
        print(f"❌ 检查 requirements.txt 失败: {e}")
        return False


def create_plugin_package():
    """创建插件包"""
    print("\n📦 创建插件包...")
    
    package_name = "aihubmix-image.zip"
    
    # 排除的文件和目录
    exclusions = [
        "*.git*",
        "*.pyc",
        "__pycache__",
        ".DS_Store",
        "tests/",
        "*.md",
        "build_plugin.py",
        "test_plugin.py",
        ".env",
        ".env.example"
    ]
    
    try:
        with zipfile.ZipFile(package_name, 'w', zipfile.ZIP_DEFLATED) as zipf:
            for root, dirs, files in os.walk('.'):
                # 跳过隐藏目录
                dirs[:] = [d for d in dirs if not d.startswith('.')]
                
                for file in files:
                    file_path = os.path.join(root, file)
                    
                    # 检查是否应该排除
                    should_exclude = False
                    for exclusion in exclusions:
                        if exclusion.endswith('/'):
                            # 目录排除
                            if file_path.startswith(exclusion):
                                should_exclude = True
                                break
                        else:
                            # 文件模式排除
                            if file_path.startswith(exclusion.rstrip('*')):
                                should_exclude = True
                                break
                    
                    if not should_exclude:
                        zipf.write(file_path, file_path)
                        print(f"📄 添加文件: {file_path}")
        
        print(f"✅ 插件包创建成功: {package_name}")
        
        # 显示包信息
        file_size = os.path.getsize(package_name)
        print(f"📊 包大小: {file_size:,} 字节")
        
        # 计算文件哈希
        file_hash = calculate_file_hash(package_name)
        print(f"🔐 MD5: {file_hash}")
        
        return True
        
    except Exception as e:
        print(f"❌ 创建插件包失败: {e}")
        return False


def verify_package():
    """验证插件包"""
    print("\n🔍 验证插件包...")
    
    package_name = "aihubmix-image.zip"
    
    if not os.path.exists(package_name):
        print("❌ 插件包不存在")
        return False
    
    try:
        with zipfile.ZipFile(package_name, 'r') as zipf:
            file_list = zipf.namelist()
            
        print(f"📦 包中文件数量: {len(file_list)}")
        print("📄 文件列表:")
        for file_path in sorted(file_list):
            print(f"   - {file_path}")
        
        # 检查必要文件是否在包中
        required_files = [
            "manifest.yaml",
            "provider/aihubmix-image.yaml",
            "provider/aihubmix-image.py",
            "tools/aihubmix-image.yaml",
            "tools/aihubmix-image.py",
            "requirements.txt"
        ]
        
        missing_in_package = []
        for required_file in required_files:
            if required_file not in file_list:
                missing_in_package.append(required_file)
        
        if missing_in_package:
            print("❌ 包中缺少必要文件:")
            for file_path in missing_in_package:
                print(f"   - {file_path}")
            return False
        
        print("✅ 插件包验证通过")
        return True
        
    except Exception as e:
        print(f"❌ 验证插件包失败: {e}")
        return False


def main():
    """主函数"""
    print("🚀 Aihubmix Image Generation Plugin 构建工具")
    print("=" * 60)
    
    # 切换到插件目录
    script_dir = os.path.dirname(os.path.abspath(__file__))
    os.chdir(script_dir)
    
    # 执行验证步骤
    steps = [
        ("目录结构", validate_plugin_structure),
        ("YAML 语法", validate_yaml_syntax),
        ("Python 语法", validate_python_syntax),
        ("依赖文件", check_dependencies),
        ("创建包", create_plugin_package),
        ("验证包", verify_package)
    ]
    
    all_passed = True
    
    for step_name, step_func in steps:
        try:
            if not step_func():
                all_passed = False
                break
        except KeyboardInterrupt:
            print(f"\n⏹️  构建被用户中断")
            sys.exit(1)
        except Exception as e:
            print(f"❌ {step_name}验证失败: {e}")
            all_passed = False
            break
    
    print("\n" + "=" * 60)
    
    if all_passed:
        print("🎉 构建成功！")
        print("\n📋 下一步:")
        print("1. 将 aihubmix-image.zip 上传到 Dify")
        print("2. 在 Dify 中配置 Aihubmix API Key")
        print("3. 开始使用插件")
        print("\n📖 详细说明请查看:")
        print("- USAGE.md (使用说明)")
        print("- DEPLOYMENT.md (部署指南)")
    else:
        print("❌ 构建失败，请检查上述错误")
        sys.exit(1)


if __name__ == "__main__":
    main()
