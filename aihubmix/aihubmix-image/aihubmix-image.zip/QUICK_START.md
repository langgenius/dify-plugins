# Aihubmix Image Generation Plugin 快速开始指南

## 🚀 快速设置

### 1. 配置 API Key

#### 方法一：环境变量配置（推荐用于本地测试）

```bash
# 复制环境变量模板
cp .env.example .env

# 编辑 .env 文件，填入您的 API Key
nano .env
```

在 `.env` 文件中填入：
```
AIHUBMIX_API_KEY=your_actual_api_key_here
```

#### 方法二：Dify 插件配置（生产环境）

1. 登录 Dify 管理后台
2. 进入「插件管理」
3. 找到「aihubmix-image」插件
4. 点击「配置」
5. 在「API Key」字段中填入您的密钥
6. 点击「保存」

### 2. 获取 API Key

1. 访问 [Aihubmix 官网](https://docs.aihubmix.com)
2. 注册/登录账号
3. 进入控制台/API 管理页面
4. 生成新的 API Key
5. 复制 API Key

### 3. 本地测试

```bash
# 安装依赖
pip install -r requirements.txt

# 配置环境变量（如果还没有配置）
cp .env.example .env
# 编辑 .env 文件填入 API Key

# 启动插件服务
python3 main.py
```

### 4. 测试 API 连接

插件启动后，您可以通过以下方式测试：

#### 使用 curl 测试
```bash
curl -X POST http://localhost:5001/tools/invoke \
  -H "Content-Type: application/json" \
  -d '{
    "tool_name": "aihubmix-image",
    "tool_parameters": {
      "prompt": "A beautiful sunset over mountains",
      "model": "opanai/dall-e-3",
      "resolution": "1024x1024",
      "num_images": 1,
      "moderation_level": 3
    }
  }'
```

#### 在 Dify 中测试
1. 创建新的 ChatFlow 应用
2. 添加工具节点
3. 选择「aihubmix-image」工具
4. 输入测试提示词
5. 运行测试

## 📋 支持的模型

### 同步模型（即时返回）
- `opanai/dall-e-3` - DALL-E 3（推荐）
- `opanai/gpt-image-1` - GPT Image 1（快速）
- `stability/Stable-Diffusion-3-5-Large` - Stable Diffusion 3.5 Large（艺术风格）
- `qianfan/qwen-image` - Qwen Image（中文优化）

### 异步模型（需要轮询）
- `bfl/flux-kontext-max` - Flux Kontext Max（高质量）
- `bfl/flux-kontext-pro` - Flux Kontext Pro（平衡）

## ⚙️ 参数说明

| 参数 | 类型 | 必填 | 默认值 | 说明 |
|------|------|------|--------|------|
| prompt | string | ✅ | - | 图像生成提示词 |
| model | select | ❌ | opanai/dall-e-3 | 选择模型 |
| resolution | select | ❌ | 1024x1024 | 图像分辨率 |
| num_images | number | ❌ | 1 | 生成数量（1-4） |
| moderation_level | number | ❌ | 3 | 审核宽松度（0-6） |

## 🔧 常见问题

### Q: 提示 "API Key is required"
**A**: 需要配置 API Key：
- 本地测试：编辑 `.env` 文件
- Dify 环境：在插件配置中填入

### Q: 提示 "Invalid API Key"
**A**: 检查 API Key 是否：
- 正确复制（无空格和换行）
- 仍然有效
- 有足够的配额

### Q: 异步模型超时
**A**: 这是正常现象：
- 复杂图像需要更长时间
- 可以尝试简化提示词
- 选择同步模型获得更快响应

### Q: 生成失败
**A**: 检查：
- 提示词是否符合内容政策
- 审核宽松度设置
- 网络连接状态

## 📞 技术支持

- 📖 [详细使用说明](USAGE.md)
- 🚀 [部署指南](DEPLOYMENT.md)
- 🐛 [问题反馈](https://github.com/your-repo/issues)
- 📧 [技术支持](mailto:support@aihubmix.com)

---

**提示**: 首次使用建议先用同步模型测试，确认配置正确后再尝试异步模型。
