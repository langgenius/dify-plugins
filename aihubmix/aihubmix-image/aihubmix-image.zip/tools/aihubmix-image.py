import json
import time
import requests
import base64
from collections.abc import Generator
from typing import Any, Dict, List
from tenacity import retry, stop_after_attempt, wait_exponential

from dify_plugin import Tool
from dify_plugin.entities.tool import ToolInvokeMessage


class AihubmixImageTool(Tool):
    """
    Aihubmix 图像生成工具
    支持所有主流生图模型，包括同步、异步和直接调用模型
    """
    
    # 同步模型列表（使用 /predictions 接口）
    SYNC_MODELS = {
        "opanai/gpt-image-1",
        "opanai/dall-e-3",
        "google/imagen-4.0-ultra-generate-001",
        "google/imagen-4.0-generate-001",
        "google/imagen-4.0-fast-generate-001",
        "google/imagen-4.0-fast-generate-preview-06-06",
        "google/imagen-3.0-generate-002",
        "qianfan/qwen-image",
        "qianfan/qwen-image-edit",
        "doubao/doubao-seedream-4-0-250828",
        "ideogram/V3",
        "stability/Stable-Diffusion-3-5-Large",
        "qianfan/irag-1.0",
        "qianfan/ernie-irag-edit"
    }
    
    # 异步模型列表（需要轮询）
    ASYNC_MODELS = {
        "bfl/flux-kontext-max",
        "bfl/flux-kontext-pro"
    }
    
    # 直接调用模型列表（使用 /images/generations 接口）
    DIRECT_MODELS = {
        "FLUX.1-Kontext-pro",
        "FLUX-1.1-pro"
    }
    
    def _invoke(self, tool_parameters: dict[str, Any]) -> Generator[ToolInvokeMessage]:
        """
        工具调用入口
        """
        try:
            # 获取参数
            prompt = tool_parameters.get("prompt", "").strip()
            model = tool_parameters.get("model", "opanai/dall-e-3")
            size = tool_parameters.get("size", "1024x1024")
            n = int(tool_parameters.get("n", 1))
            moderation_level = int(tool_parameters.get("moderation_level", 3))
            
            # 参数验证
            if not prompt:
                yield self.create_text_message("错误：提示词不能为空")
                return
            
            if n < 1 or n > 4:
                yield self.create_text_message("错误：图像数量必须在 1-4 之间")
                return
                
            if moderation_level < 0 or moderation_level > 6:
                yield self.create_text_message("错误：审核宽松度必须在 0-6 之间")
                return
            
            # 获取 API Key
            api_key = self.runtime.credentials.get("api_key")
            if not api_key:
                yield self.create_text_message("错误：未配置 Aihubmix API Key")
                return
            
            # 发送开始消息
            yield self.create_text_message(f"开始生成图像...\n模型: {model}\n提示词: {prompt[:100]}{'...' if len(prompt) > 100 else ''}")
            
            # 根据模型类型选择调用方式
            if model in self.SYNC_MODELS:
                result = self._generate_sync_image(api_key, prompt, model, size, n, moderation_level)
            elif model in self.ASYNC_MODELS:
                result = self._generate_async_image(api_key, prompt, model, size, n, moderation_level)
            elif model in self.DIRECT_MODELS:
                result = self._generate_direct_image(api_key, prompt, model, size, n, moderation_level)
            else:
                yield self.create_text_message(f"错误：不支持的模型 {model}")
                return
            
            # 返回结果
            if result.get("success"):
                yield self.create_json_message({
                    "success": True,
                    "model": model,
                    "prompt": prompt,
                    "images": result.get("images", []),
                    "message": f"成功生成 {len(result.get('images', []))} 张图像"
                })
            else:
                yield self.create_text_message(f"图像生成失败: {result.get('error', '未知错误')}")
                
        except Exception as e:
            yield self.create_text_message(f"工具执行错误: {str(e)}")
    
    @retry(stop=stop_after_attempt(3), wait=wait_exponential(multiplier=1, min=4, max=10))
    def _make_api_request(self, url: str, headers: Dict[str, str], payload: Dict[str, Any]) -> requests.Response:
        """
        发起 API 请求，带重试机制
        """
        response = requests.post(url, headers=headers, json=payload, timeout=60)
        response.raise_for_status()
        return response
    
    def _generate_sync_image(self, api_key: str, prompt: str, model: str, size: str, n: int, moderation_level: int) -> Dict[str, Any]:
        """
        同步模型图像生成（使用 /predictions 接口）
        """
        try:
            headers = {
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json"
            }
            
            # 根据不同模型构建不同的请求参数
            if model.startswith("opanai/"):
                # OpenAI 模型
                payload = {
                    "input": {
                        "prompt": prompt,
                        "size": size,
                        "n": n,
                        "quality": "high",
                        "moderation": "low" if moderation_level <= 2 else "medium" if moderation_level <= 4 else "high",
                        "background": "auto"
                    }
                }
            elif model.startswith("google/"):
                # Google Imagen 模型
                payload = {
                    "input": {
                        "prompt": prompt,
                        "numberOfImages": n
                    }
                }
            elif model.startswith("qianfan/qwen"):
                # Qwen 模型
                payload = {
                    "input": {
                        "prompt": prompt,
                        "n": n,
                        "size": size,
                        "guidance": 7.5,
                        "watermark": False
                    }
                }
            elif model.startswith("doubao/"):
                # Doubao 模型
                payload = {
                    "input": {
                        "prompt": prompt,
                        "size": "2K",
                        "sequential_image_generation": "disabled",
                        "stream": False,
                        "response_format": "url",
                        "watermark": True
                    }
                }
            elif model.startswith("ideogram/"):
                # Ideogram 模型
                payload = {
                    "input": {
                        "prompt": prompt,
                        "rendering_speed": "QUALITY",
                        "aspect_ratio": "1x1"
                    }
                }
            elif model.startswith("stability/"):
                # Stability 模型
                payload = {
                    "input": {
                        "prompt": prompt,
                        "n": n
                    }
                }
            elif model.startswith("qianfan/irag") or model.startswith("qianfan/ernie"):
                # ERNIE 模型
                payload = {
                    "input": {
                        "prompt": prompt,
                        "n": n,
                        "size": size,
                        "guidance": 7.5,
                        "watermark": False
                    }
                }
            else:
                # 默认参数
                payload = {
                    "input": {
                        "prompt": prompt,
                        "size": size,
                        "n": n
                    }
                }
            
            url = f"https://aihubmix.com/v1/models/{model}/predictions"
            response = self._make_api_request(url, headers, payload)
            data = response.json()
            
            # 处理不同模型的响应格式
            if "output" in data and isinstance(data["output"], list):
                images = []
                for item in data["output"]:
                    if "url" in item:
                        images.append(item["url"])
                
                if images:
                    return {
                        "success": True,
                        "images": images
                    }
            
            return {
                "success": False,
                "error": f"API 返回格式异常: {json.dumps(data, ensure_ascii=False)}"
            }
            
        except requests.exceptions.RequestException as e:
            return {
                "success": False,
                "error": f"网络请求失败: {str(e)}"
            }
        except Exception as e:
            return {
                "success": False,
                "error": f"同步生成失败: {str(e)}"
            }
    
    def _generate_async_image(self, api_key: str, prompt: str, model: str, size: str, n: int, moderation_level: int) -> Dict[str, Any]:
        """
        异步模型图像生成（Flux 系列，需要轮询）
        """
        try:
            headers = {
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json"
            }
            
            # 第一步：提交生成任务
            payload = {
                "input": {
                    "prompt": prompt,
                    "aspect_ratio": "1x1",  # 默认比例
                    "safety_tolerance": moderation_level
                }
            }
            
            url = f"https://aihubmix.com/v1/models/{model}/predictions"
            response = self._make_api_request(url, headers, payload)
            data = response.json()
            
            if "output" not in data or not isinstance(data["output"], list) or len(data["output"]) == 0:
                return {
                    "success": False,
                    "error": "异步任务提交失败，未返回 polling_url 或 taskId"
                }
            
            task_info = data["output"][0]
            if "polling_url" not in task_info:
                return {
                    "success": False,
                    "error": "异步任务提交失败，未返回 polling_url"
                }
            
            polling_url = task_info["polling_url"]
            
            # 第二步：轮询获取结果
            max_attempts = 10
            interval = 2  # 秒
            
            for attempt in range(max_attempts):
                try:
                    # 检查任务状态
                    status_response = requests.get(polling_url, headers=headers, timeout=10)
                    status_response.raise_for_status()
                    
                    status_data = status_response.json()
                    
                    if status_data.get("status") == "completed":
                        # 任务完成，获取图像
                        if "output" in status_data and isinstance(status_data["output"], list):
                            images = []
                            for item in status_data["output"]:
                                if "url" in item:
                                    images.append(item["url"])
                            
                            if images:
                                return {
                                    "success": True,
                                    "images": images
                                }
                        
                        return {
                            "success": False,
                            "error": "任务完成但未获取到图像链接"
                        }
                    
                    elif status_data.get("status") == "failed":
                        return {
                            "success": False,
                            "error": f"异步任务失败: {status_data.get('error', '未知错误')}"
                        }
                    
                    # 任务仍在进行中，继续等待
                    if attempt < max_attempts - 1:
                        time.sleep(interval)
                
                except requests.exceptions.RequestException as e:
                    if attempt == max_attempts - 1:
                        return {
                            "success": False,
                            "error": f"轮询状态失败: {str(e)}"
                        }
                    time.sleep(interval)
            
            # 轮询超时
            return {
                "success": False,
                "error": f"异步任务超时，已轮询 {max_attempts} 次"
            }
            
        except Exception as e:
            return {
                "success": False,
                "error": f"异步生成失败: {str(e)}"
            }
    
    def _generate_direct_image(self, api_key: str, prompt: str, model: str, size: str, n: int, moderation_level: int) -> Dict[str, Any]:
        """
        直接调用模型图像生成（FLUX.1 系列，使用 /images/generations 接口）
        """
        try:
            headers = {
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json"
            }
            
            payload = {
                "prompt": prompt,
                "model": model,
                "safety_tolerance": moderation_level,
                "response_format": "url"
            }
            
            response = self._make_api_request(
                "https://aihubmix.com/v1/images/generations",
                headers,
                payload
            )
            
            data = response.json()
            
            if "data" in data and isinstance(data["data"], list):
                images = []
                for item in data["data"]:
                    if "url" in item:
                        images.append(item["url"])
                    elif "b64_json" in item:
                        # 处理 base64 返回
                        try:
                            image_data = base64.b64decode(item["b64_json"])
                            # 这里可以保存为临时文件或上传到存储
                            # 为简化，我们返回 base64 数据
                            images.append(f"data:image/png;base64,{item['b64_json']}")
                        except Exception:
                            pass
                
                if images:
                    return {
                        "success": True,
                        "images": images
                    }
            
            return {
                "success": False,
                "error": f"API 返回格式异常: {json.dumps(data, ensure_ascii=False)}"
            }
            
        except requests.exceptions.RequestException as e:
            return {
                "success": False,
                "error": f"网络请求失败: {str(e)}"
            }
        except Exception as e:
            return {
                "success": False,
                "error": f"直接生成失败: {str(e)}"
            }
