import json
import time
import requests
from collections.abc import Generator
from typing import Any, Dict, List

from dify_plugin import Tool
from dify_plugin.entities.tool import ToolInvokeMessage


class FluxKontextTool(Tool):
    """
    Flux Kontext Image Generation Tool
    Uses bfl/flux-kontext models for high quality async image generation
    """
    
    # API endpoints
    BASE_URL = "https://api.aihubmix.com/v1"
    ASYNC_ENDPOINT = f"{BASE_URL}/images/async-generations"
    RESULT_ENDPOINT = f"{BASE_URL}/images/generations/{{task_id}}"
    
    def _invoke(self, tool_parameters: dict[str, Any]) -> Generator[ToolInvokeMessage]:
        """
        Main invoke method for Flux Kontext image generation
        """
        try:
            # Extract and validate parameters
            prompt = tool_parameters.get("prompt", "").strip()
            if not prompt:
                raise Exception("Prompt is required")
            
            model = tool_parameters.get("model", "bfl/flux-kontext-pro")
            resolution = tool_parameters.get("resolution", "1024x1024")
            num_images = int(tool_parameters.get("num_images", 1))
            moderation_level = int(tool_parameters.get("moderation_level", 3))
            
            # Validate parameters
            if num_images < 1 or num_images > 4:
                raise Exception("Number of images must be between 1 and 4")
            
            if moderation_level < 0 or moderation_level > 6:
                raise Exception("Moderation level must be between 0 and 6")
            
            # Get API key from credentials
            api_key = self.runtime.credentials.get("api_key")
            if not api_key:
                raise Exception("API Key is required")
            
            # Prepare headers
            headers = {
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json"
            }
            
            # Parse resolution
            width, height = map(int, resolution.split("x"))
            
            # Prepare request payload for Flux
            payload = {
                "model": model,
                "prompt": prompt,
                "n": num_images,
                "size": f"{width}x{height}",
                "moderation_level": moderation_level
            }
            
            model_name = "Flux Kontext Max" if model == "bfl/flux-kontext-max" else "Flux Kontext Pro"
            yield self.create_text_message(f"Starting async image generation with {model_name}...")
            
            # Start async generation
            response = requests.post(
                self.ASYNC_ENDPOINT,
                headers=headers,
                json=payload,
                timeout=30
            )
            
            if response.status_code != 200:
                error_msg = f"Flux async generation request failed with status {response.status_code}"
                try:
                    error_data = response.json()
                    if "error" in error_data:
                        error_msg += f": {error_data['error'].get('message', 'Unknown error')}"
                except:
                    pass
                raise Exception(error_msg)
            
            data = response.json()
            
            # Get task ID
            task_id = data.get("task_id")
            if not task_id:
                raise Exception("No task ID received from Flux generation")
            
            yield self.create_text_message(f"Task started with ID: {task_id}. Polling for results...")
            
            # Poll for result with retry mechanism
            result = self._poll_async_result(headers, task_id)
            
            # Return results
            if result.get("images"):
                yield self.create_json_message({
                    "success": True,
                    "model": model,
                    "prompt": prompt,
                    "resolution": resolution,
                    "num_images": len(result["images"]),
                    "images": result["images"],
                    "moderation_level": moderation_level,
                    "task_id": task_id
                })
                
                # Also create text message with image URLs
                image_urls = "\n".join([f"- {img['url']}" for img in result["images"]])
                yield self.create_text_message(f"{model_name} generated {len(result['images'])} image(s):\n{image_urls}")
            else:
                raise Exception("No images were generated")
                
        except Exception as e:
            raise Exception(f"Flux Kontext image generation failed: {str(e)}")
    
    def _poll_async_result(self, headers: Dict[str, str], task_id: str, max_retries: int = 10, retry_interval: int = 2) -> Dict[str, Any]:
        """
        Poll for async generation result with retry mechanism
        """
        result_url = self.RESULT_ENDPOINT.format(task_id=task_id)
        
        for attempt in range(max_retries):
            try:
                response = requests.get(
                    result_url,
                    headers=headers,
                    timeout=30
                )
                
                if response.status_code != 200:
                    if attempt == max_retries - 1:
                        raise Exception(f"Failed to get result after {max_retries} attempts")
                    time.sleep(retry_interval)
                    continue
                
                data = response.json()
                status = data.get("status", "unknown")
                
                if status == "completed":
                    # Extract image URLs
                    images = []
                    if "data" in data and isinstance(data["data"], list):
                        for item in data["data"]:
                            if "url" in item:
                                images.append({"url": item["url"]})
                    
                    if images:
                        return {"images": images}
                    else:
                        raise Exception("Generation completed but no images found")
                
                elif status == "failed":
                    error_msg = data.get("error", "Flux generation failed")
                    raise Exception(f"Flux generation failed: {error_msg}")
                
                elif status in ["pending", "processing"]:
                    # Still processing, wait and retry
                    if attempt < max_retries - 1:
                        yield self.create_text_message(f"Processing... (attempt {attempt + 1}/{max_retries})")
                        time.sleep(retry_interval)
                        continue
                    else:
                        raise Exception(f"Generation timed out after {max_retries} attempts")
                
                else:
                    # Unknown status
                    if attempt == max_retries - 1:
                        raise Exception(f"Unknown status: {status}")
                    time.sleep(retry_interval)
                    
            except requests.exceptions.RequestException as e:
                if attempt == max_retries - 1:
                    raise Exception(f"Network error during polling: {str(e)}")
                time.sleep(retry_interval)
        
        raise Exception(f"Failed to get result after {max_retries} attempts")
