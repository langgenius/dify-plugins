# Huoban API Suite - Dify Plugin

[![Dify Plugin](https://img.shields.io/badge/Dify-Plugin-blue)](https://dify.ai)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Version](https://img.shields.io/badge/version-1.2.0-green)](https://github.com/your-repo/huoban-plugin-dify)

A comprehensive Huoban API plugin for Dify AI platform that provides full CRUD operations, workspace management, and data automation capabilities. This plugin enables Dify AI agents to interact with Huoban (伙伴云) platform for intelligent business automation.

## 🚀 Features

### Workspace & Data Management
- **Workspace Discovery**: List all accessible workspaces (spaces)
- **Table Exploration**: Explore tables within workspaces with detailed field configurations
- **Intelligent Data Operations**: Create, read, update, and delete records in Huoban tables
- **Advanced Querying**: Complex filtering with AND/OR logical operations
- **Member Management**: Retrieve workspace member information for user assignments

### AI-Powered Automation
- **Autonomous Exploration**: Step-by-step workflow for AI agents to discover data structures
- **Smart Field Mapping**: Automatic field ID detection and validation
- **Error-Resilient Design**: Comprehensive error handling and recovery mechanisms
- **Multi-Language Support**: Full English and Chinese interface support

## 📦 Installation

### Dify Marketplace Installation (Recommended)
1. Navigate to **Dify Marketplace** in your Dify instance
2. Search for **"Huoban API Suite"** or **"伙伴云全能工具箱"**
3. Click **"Install"** and follow the setup wizard
4. Configure authentication with your Huoban API key

### Manual Installation
1. Download the latest plugin package: `huoban-plugin-dify.zip`
2. In Dify, go to **Settings → Plugins → Add Plugin**
3. Upload the plugin package
4. Configure authentication as described below

## 🔐 Authentication Configuration

This plugin uses secure API key authentication:

1. **Obtain API Key**: Get your API key from [Huoban Platform](https://www.huoban.com)
2. **Configure in Dify**: When adding the plugin, enter your API key in the format:
   ```
   Bearer {YOUR_API_KEY}
   ```
3. **Security Note**: API keys are securely stored and encrypted within Dify

## 🛠️ Available Tools

### 1. `get_workspace_list` - 获取工作区列表
Lists all workspaces accessible to the current user. **Start here** when you need to discover available workspaces.

### 2. `get_table_list` - 获取表格列表
Retrieves all tables within a specified workspace. Use this to find your target table's `table_id`.

### 3. `get_table_config` - 获取表格配置
**Core Interface**: Gets detailed field configuration for a specific table. **Must be called before any data operations** to obtain accurate `field_id` mappings.

### 4. `create_record` - 创建记录
Creates a new record in the specified table. Fields must use `field_id` as keys (obtained from `get_table_config`).

### 5. `query_table_data` - 查询表格数据
Queries table data with complex filtering conditions. Supports AND/OR logical nesting for advanced queries.

### 6. `get_item_detail` - 获取记录详情
Gets complete details of a specific record by its `item_id`.

### 7. `update_record` - 更新记录
Updates an existing record. Requires `item_id` and fields to update.

### 8. `delete_record` - 删除记录
Deletes a specific record. **Warning**: This operation cannot be undone.

### 9. `get_space_members` - 获取空间成员
Retrieves member information within a workspace. Essential when filling "person" type fields.

## 📖 Usage Examples

### Basic AI Agent Workflow
```yaml
# Example Dify workflow configuration
steps:
  - name: discover_structure
    type: tool
    tool: huoban/get_workspace_list
    
  - name: find_tables
    type: tool
    tool: huoban/get_table_list
    parameters:
      space_id: "{{steps.discover_structure.output.workspaces[0].id}}"
      
  - name: get_table_config
    type: tool
    tool: huoban/get_table_config
    parameters:
      table_id: "{{steps.find_tables.output.tables[0].table_id}}"
      
  - name: create_customer
    type: tool
    tool: huoban/create_record
    parameters:
      table_id: "{{steps.get_table_config.output.table_id}}"
      fields:
        "company_name_field": "Acme Corporation"
        "contact_field": "John Doe"
        "status_field": "Active"
```

### Real-World Use Cases
1. **CRM Automation**: Automatically create customer records from lead data
2. **Project Management**: Update task statuses and assign team members
3. **Inventory Tracking**: Query and update product inventory levels
4. **Customer Support**: Create and track support tickets
5. **Sales Pipeline**: Manage sales opportunities and follow-ups

## 🔧 Field ID Mapping System

**Critical Information**: Huoban uses unique `field_id` values for each table field. These IDs:
- Are unique to each table and workspace
- Cannot be guessed or hardcoded
- Must be obtained via `get_table_config` before any data operations

**Best Practice Workflow**:
```
get_workspace_list → get_table_list → get_table_config → [data operations]
```

## ⚠️ Error Handling & Troubleshooting

The plugin includes comprehensive error handling:

| Error Type | Description | Solution |
|------------|-------------|----------|
| Authentication Error | Invalid or expired API key | Regenerate API key in Huoban platform |
| Permission Denied | Insufficient workspace permissions | Check user permissions in Huoban |
| Invalid Field ID | Incorrect field_id used | Call `get_table_config` to get correct IDs |
| Rate Limit Exceeded | Too many API requests | Wait 1 minute and retry |
| Network Error | Connection issues | Check internet connection and retry |

## 📞 Support & Resources

### Documentation
- **Huoban API Documentation**: [https://docs.huoban.com](https://docs.huoban.com)
- **Dify Plugin Development Guide**: [https://docs.dify.ai/plugins](https://docs.dify.ai/plugins)

### Support Channels
- **Plugin Issues**: [GitHub Issues](https://github.com/your-repo/huoban-plugin-dify/issues)
- **Huoban Support**: [support@huoban.com](mailto:support@huoban.com)
- **Dify Community**: [Dify Discord](https://discord.gg/dify)

### Privacy & Compliance
- **Privacy Policy**: [PRIVACY.md](PRIVACY.md)
- **Data Security**: All data transmitted via HTTPS encryption
- **GDPR Compliance**: Designed with privacy-by-default principles

## 📋 Changelog

### v1.2.0 (Current)
- **Added**: Comprehensive 9-tool API suite
- **Improved**: Multi-language support (en_US, zh_Hans)
- **Enhanced**: Error handling and user feedback
- **Updated**: Complete documentation and examples

### v1.1.0
- **Added**: Basic CRUD operations
- **Implemented**: API key authentication
- **Created**: Initial plugin structure

### v1.0.0
- **Initial Release**: Basic workspace and table discovery

## 📄 License

This plugin is licensed under the **MIT License** - see the [LICENSE](LICENSE) file for details.

## 🤝 Contributing

We welcome contributions! Please see [CONTRIBUTING.md](CONTRIBUTING.md) for guidelines on:
- Reporting issues
- Submitting pull requests
- Code style and standards
- Testing requirements

## 🎯 Dify Marketplace Requirements Checklist

- [x] Complete `manifest.json` with all required fields
- [x] Comprehensive `README.md` documentation
- [x] Privacy policy (`PRIVACY.md`)
- [x] License file (`LICENSE`)
- [x] OpenAPI specification (`openapi.json`)
- [x] Plugin package (`huoban-plugin-dify.zip`)
- [x] Multi-language support (en_US, zh_Hans)
- [x] Clear error handling and user feedback
- [x] Security best practices (HTTPS, no data storage)
- [x] Version management and changelog

---

**Ready for Dify Marketplace Submission!** 🚀
